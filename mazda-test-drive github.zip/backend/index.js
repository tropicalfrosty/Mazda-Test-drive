// backend/index.js
// Express API: inventory + PDF fill
// Install deps: npm i express multer cors pdf-lib dayjs

import express from "express";
import cors from "cors";
import multer from "multer";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { PDFDocument } from "pdf-lib";
import dayjs from "dayjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// Storage for uploads
const uploadsDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const safe = file.originalname.replace(/[^a-z0-9_.-]/gi, "_");
    cb(null, Date.now() + "_" + safe);
  },
});
const upload = multer({ storage });

// Template path
const templatePath = path.join(__dirname, "templates", "TEST DRIVE AGREEMENT.pdf");

// Mock inventory (swap with real feed later)
const inventory = [
  { id: "1", year: 2023, make: "Mazda", model: "CX-5", stock: "SN001" },
  { id: "2", year: 2024, make: "Mazda", model: "Mazda3", stock: "SN002" },
  { id: "3", year: 2023, make: "Mazda", model: "CX-50", stock: "SN003" },
  { id: "4", year: 2025, make: "Mazda", model: "CX-70", stock: "SN004" },
];

// GET /api/vehicles?q=
app.get("/api/vehicles", (req, res) => {
  const q = (req.query.q || "").toString().toLowerCase().trim();
  if (!q) return res.json(inventory);
  const filtered = inventory.filter((v) =>
    [v.year, v.make, v.model, v.stock]
      .map((x) => String(x).toLowerCase())
      .some((s) => s.includes(q))
  );
  res.json(filtered);
});

// POST /api/test-drive (multipart form)
app.post(
  "/api/test-drive",
  upload.fields([
    { name: "licenseFile", maxCount: 1 },
    { name: "insuranceFile", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const {
        name,
        phone,
        insurance,
        policy,
        license,
        state,
        exp,
        year,
        make,
        model,
        stock,
        vehicleId,
      } = req.body;

      if (!fs.existsSync(templatePath)) {
        return res.status(500).json({ error: "Template PDF missing" });
      }
      const bytes = fs.readFileSync(templatePath);
      const pdfDoc = await PDFDocument.load(bytes);
      const form = pdfDoc.getForm();

      const safeSet = (field, value) => {
        try { form.getTextField(field).setText(value ?? ""); } catch { /* ignore */ }
      };

      // Field names from provided template
      safeSet("DV_CustomerPrimaryFullName", name);
      safeSet("DV_CustomerCellPhoneORHomePhone", phone);
      safeSet("DV_VehicleYear", String(year || ""));
      safeSet("DV_VehicleMake", make || "");
      safeSet("DV_VehicleModel", model || "");
      safeSet("DV_CustomerInsuranceInsurer", insurance || "");
      safeSet("DV_CustomerInsurancePolicyNumber", policy || "");
      safeSet("DV_VehicleStockNumber", stock || "");
      safeSet("DV_CustomerDriversLicenseNumber", license || "");
      safeSet("DV_CustomerDriversLicenseState", state || "");
      safeSet("DV_CustomerDriversLicenseExperation", exp || "");
      safeSet("DV_CurrentDate", dayjs().format("MM/DD/YYYY"));

      form.flatten();

      const pdfBytes = await pdfDoc.save();

      const filename = `Test-Drive-${stock || vehicleId || "vehicle"}.pdf`;
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.send(Buffer.from(pdfBytes));
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Failed to generate PDF" });
    }
  }
);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`API running on :${PORT}`));
