import React, { useEffect, useState } from 'react'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000'

export default function App() {
  const [selectedCar, setSelectedCar] = useState(null)
  const [cars, setCars] = useState([])
  const [allCars, setAllCars] = useState([])
  const [loadingCars, setLoadingCars] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [search, setSearch] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    insurance: '',
    policy: '',
    license: '',
    state: '',
    exp: '',
    licenseFile: null,
    insuranceFile: null,
  })

  // Load initial inventory
  useEffect(() => {
    const load = async () => {
      try {
        setLoadingCars(true)
        const res = await fetch(`${API_URL}/api/vehicles`)
        const data = await res.json()
        setCars(data)
        setAllCars(data)
      } catch (e) {
        console.error(e)
      } finally {
        setLoadingCars(false)
      }
    }
    load()
  }, [])

  // Local filter
  useEffect(() => {
    if (!search) return setCars(allCars)
    const q = search.toLowerCase()
    setCars(
      allCars.filter(v =>
        [v.year, v.make, v.model, v.stock]
          .map(x => String(x).toLowerCase())
          .some(s => s.includes(q))
      )
    )
  }, [search, allCars])

  // Debounced server search
  useEffect(() => {
    const t = setTimeout(async () => {
      if (search.length > 2) {
        try {
          setLoadingCars(true)
          const res = await fetch(`${API_URL}/api/vehicles?q=${encodeURIComponent(search)}`)
          const data = await res.json()
          setCars(data)
        } catch (e) {
          console.error(e)
        } finally {
          setLoadingCars(false)
        }
      }
    }, 400)
    return () => clearTimeout(t)
  }, [search])

  const onChange = (e) => {
    const { name, value, files } = e.target
    if (files) setFormData(prev => ({ ...prev, [name]: files[0] }))
    else setFormData(prev => ({ ...prev, [name]: value }))
  }

  const highlight = (text) => {
    if (!search) return text
    const parts = String(text).split(new RegExp(`(${search})`, 'ig'))
    return parts.map((part, i) =>
      part.toLowerCase() === search.toLowerCase()
        ? <mark key={i} style={{ fontWeight: 700 }}>{part}</mark>
        : <React.Fragment key={i}>{part}</React.Fragment>
    )
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!selectedCar) return
    try {
      setSubmitting(true)
      const body = new FormData()
      const fields = ['name','phone','insurance','policy','license','state','exp']
      fields.forEach(k => body.append(k, formData[k]))
      body.append('vehicleId', selectedCar.id)
      body.append('year', selectedCar.year)
      body.append('make', selectedCar.make)
      body.append('model', selectedCar.model)
      body.append('stock', selectedCar.stock)
      if (formData.licenseFile) body.append('licenseFile', formData.licenseFile)
      if (formData.insuranceFile) body.append('insuranceFile', formData.insuranceFile)

      const res = await fetch(`${API_URL}/api/test-drive`, { method: 'POST', body })
      if (!res.ok) throw new Error('PDF generation failed')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `Test-Drive-${selectedCar.stock || selectedCar.id}.pdf`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
    } catch (err) {
      console.error(err)
      alert('There was an error creating your agreement.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div style={{ padding: 16, display: 'grid', gap: 16, gridTemplateColumns: '1fr', maxWidth: 1000, margin: '0 auto' }}>
      <div>
        <h2>Select a Car</h2>
        <input
          placeholder="Search cars (year, make, model, stock)"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ padding: 10, width: '100%', marginBottom: 12 }}
        />
        {loadingCars ? <p>Loading inventory…</p> : (
          <div style={{ display: 'grid', gap: 8 }}>
            {cars.length === 0 && <p>No cars found.</p>}
            {cars.map((car) => (
              <div
                key={car.id}
                onClick={() => setSelectedCar(car)}
                style={{
                  border: '1px solid #ddd',
                  borderRadius: 12,
                  padding: 12,
                  cursor: 'pointer',
                  background: selectedCar?.id === car.id ? '#eef6ff' : 'white'
                }}
              >
                <div style={{ fontWeight: 700 }}>{highlight(`${car.year} ${car.make} ${car.model}`)}</div>
                <div style={{ fontSize: 12, color: '#555' }}>Stock #: {highlight(car.stock)}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <h2>Test Drive Request</h2>
        {selectedCar ? (
          <form onSubmit={handleSubmit} style={{ display: 'grid', gap: 10 }}>
            <label>Full Name<input name="name" value={formData.name} onChange={onChange} required /></label>
            <label>Phone<input name="phone" value={formData.phone} onChange={onChange} required /></label>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <label>Insurance<input name="insurance" value={formData.insurance} onChange={onChange} required /></label>
              <label>Policy #<input name="policy" value={formData.policy} onChange={onChange} required /></label>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
              <label>DL #<input name="license" value={formData.license} onChange={onChange} required /></label>
              <label>State<input name="state" value={formData.state} onChange={onChange} required /></label>
              <label>Exp. Date<input name="exp" value={formData.exp} onChange={onChange} placeholder="MM/DD/YYYY" required /></label>
            </div>
            <label>Upload Driver's License<input type="file" name="licenseFile" onChange={onChange} accept="image/*,.pdf" required /></label>
            <label>Upload Insurance Card<input type="file" name="insuranceFile" onChange={onChange} accept="image/*,.pdf" required /></label>
            <button type="submit" disabled={submitting} style={{ padding: 10 }}>
              {submitting ? 'Generating PDF…' : 'Submit Request'}
            </button>
          </form>
        ) : (
          <p>Select a car to start your test drive request.</p>
        )}
      </div>
    </div>
  )
}
